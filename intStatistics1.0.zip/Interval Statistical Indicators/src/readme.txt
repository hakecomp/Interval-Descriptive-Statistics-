UFPel - Universidade Federal de Pelotas

This module requires fpconst and IntPy.

How to Install:
1 - Excute the command python setup.py install
2 - In your code insert from intStatistics import *
3 - Execute the example.py



